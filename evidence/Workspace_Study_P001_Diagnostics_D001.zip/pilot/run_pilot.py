import os,json,time,hashlib,csv,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
# Engineering configuration recorded before training, not a confirmatory freeze.
CONFIG=dict(n=list(range(4,11)),rounds=[2,4,6],families=['path','ring','all_to_all'],templates_per_cell=6,angles_per_template=4,train_templates_per_cell=4,validation_templates_per_cell=2,width=64,layers=3,heads=4,ffn=128,padding=179,epochs=12,batch=32,learning_rate=0.001,seeds=[101,202,303],workspace=[0,4],purpose='exploratory CPU feasibility; no confirmatory test set')
def digest(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def simulate(n,gates,angles):
 s=np.zeros(2**n,dtype=np.complex128);s[0]=1;a=iter(angles);idx=np.arange(len(s))
 for typ,i,j in gates:
  if typ==3:
   dst=idx^(((idx>>i)&1)<<j);s=s[dst];continue
  t=next(a);c=np.cos(t/2);v=np.sin(t/2)
  U=([ [c,-1j*v],[-1j*v,c] ] if typ==0 else [[c,-v],[v,c]] if typ==1 else [[np.exp(-1j*t/2),0],[0,np.exp(1j*t/2)]])
  U=np.array(U);lo=idx[((idx>>i)&1)==0];hi=lo|(1<<i);x=s[lo].copy();y=s[hi].copy();s[lo]=U[0,0]*x+U[0,1]*y;s[hi]=U[1,0]*x+U[1,1]*y
 z=1-2*((idx[:,None]>>np.arange(n))&1);prob=np.abs(s)**2
 out=[prob@z[:,i] for i in range(n)]+[prob@(z[:,i]*z[:,j]) for i in range(n) for j in range(i+1,n)]
 mat=s.reshape(2**(n//2),-1);ev=np.linalg.svd(mat,compute_uv=False)**2;entropy=-sum(x*np.log2(x) for x in ev if x>1e-15)
 assert abs(prob.sum()-1)<1e-10
 return np.array(out),entropy,s

def generate():
 rng=np.random.Generator(np.random.PCG64(2026111401));ar=np.random.Generator(np.random.PCG64(2026111402));seen=set();rows=[];ledger=[];rejected=0
 for n in CONFIG['n']:
  for r in CONFIG['rounds']:
   for family in CONFIG['families']:
    edges=[(i,i+1) for i in range(n-1)]
    if family=='ring':edges+=[(n-1,0)]
    if family=='all_to_all':edges=[(i,j) for i in range(n) for j in range(i+1,n)]
    k=0
    while k<6:
     gates=[]
     for _ in range(r):
      gates += [(int(rng.integers(3)),i,10) for i in range(n)]
      for _ in range(n):
       i,j=edges[int(rng.integers(len(edges)))];i,j=(j,i) if rng.integers(2) else (i,j);gates.append((3,i,j))
     tid=digest(dict(n=n,gates=gates))
     if tid in seen:
      rejected+=1
      if rejected>10000:raise RuntimeError('dedup budget exceeded')
      continue
     seen.add(tid);split='train' if k<4 else 'validation';ledger.append(dict(template=tid,n=n,r=r,family=family,split=split,gates=gates));k+=1
     for a in range(4):
      angles=ar.uniform(-np.pi,np.pi,n*r);y,e,s=simulate(n,gates,angles)
      # Independent dense full-operator check on first instance of each n=4 template.
      if n==4 and a==0:
       ref=np.zeros(16,complex);ref[0]=1;ai=0
       for typ,i,j in gates:
        if typ==3:
         M=np.zeros((16,16),complex)
         for col in range(16):M[col^((((col>>i)&1)<<j)),col]=1
        else:
         t=angles[ai];ai+=1;pa=[np.array([[0,1],[1,0]]),np.array([[0,-1j],[1j,0]]),np.diag([1,-1])][typ];u=np.cos(t/2)*np.eye(2)-1j*np.sin(t/2)*pa;M=np.array([[1]])
         for bit in reversed(range(n)):M=np.kron(M,u if bit==i else np.eye(2))
        ref=M@ref
       assert np.max(np.abs(ref-s))<1e-10
      rows.append(dict(template=tid,n=n,r=r,family=family,split=split,angles=angles.tolist(),labels=y.tolist(),entropy=e))
 # Product analytic and Bell checks, not the full planned 140-case suite.
 for t in [0,np.pi/2,np.pi]:
  y,_,_=simulate(4,[(1,0,10)],[t]);assert abs(y[0]-np.cos(t))<1e-12
 y,_,_=simulate(4,[(1,0,10),(3,0,1)],[np.pi/2]);assert abs(y[4]-1)<1e-12 and abs(y[0])<1e-12
 (ROOT/'templates.json').write_text(json.dumps(ledger));(ROOT/'instances.json').write_text(json.dumps(rows));(ROOT/'dataset_status.json').write_text(json.dumps(dict(templates=len(ledger),instances=len(rows),duplicate_draws=rejected,checks='norm all instances; dense independent n=4 first angles; analytic product and Bell',phase_tag='RZ in first rotation layer acts on initial |0>; guaranteed phase-only at that location; no general sensitivity inference')))
 return ledger,rows

def train(ledger,rows):
 import torch
 from torch import nn
 torch.set_num_threads(4)
 device='cuda' if torch.cuda.is_available() else 'cpu'
 (ROOT/'environment.json').write_text(json.dumps(dict(torch=torch.__version__,numpy=np.__version__,device=device,config=CONFIG)))
 templates={t['template']:t for t in ledger}
 def pack(row,W):
  n=row['n'];gates=templates[row['template']]['gates'];g=len(gates);q=n*(n+1)//2
  typ=np.zeros(179,int);i=np.full(179,10);j=i.copy();role=np.zeros(179,int);pos=np.zeros(179,int);ang=np.zeros((179,2),np.float32);a=iter(row['angles'])
  for k,(t,x,z) in enumerate(gates):
   typ[k]=t;i[k]=x;j[k]=z;pos[k]=k
   if t<3:v=next(a);ang[k]=[np.sin(v),np.cos(v)]
  queries=[(x,10) for x in range(n)]+[(x,z) for x in range(n) for z in range(x+1,n)]
  for k,(x,z) in enumerate(queries,g):role[k]=1;typ[k]=int(z!=10);i[k]=x;j[k]=z
  role[g+q:g+q+W]=2
  return typ,i,j,role,pos,ang,g,q,n
 class Model(nn.Module):
  def __init__(self,W):
   super().__init__();self.W=W;d=64
   self.gate=nn.Embedding(6,d);self.obs=nn.Embedding(2,d);self.first=nn.Embedding(11,d);self.second=nn.Embedding(11,d);self.role=nn.Embedding(3,d);self.n=nn.Embedding(7,d);self.pos=nn.Embedding(128,d);self.angle=nn.Linear(2,d,bias=False);self.work=nn.Parameter(torch.randn(W,d)*.02)
   self.enc=nn.TransformerEncoder(nn.TransformerEncoderLayer(d,4,128,dropout=0.,activation='gelu',batch_first=True,norm_first=True),3,enable_nested_tensor=False);self.norm=nn.LayerNorm(d);self.head=nn.Linear(d,1)
  def forward(self,b):
   typ,i,j,role,pos,ang,g,q,n=b;B=len(g);idx=torch.arange(179,device=device)[None,:];gate=idx<g[:,None];query=(idx>=g[:,None])&(idx<(g+q)[:,None]);valid=idx<(g+q+self.W)[:,None]
   x=self.first(i)+self.second(j)+self.role(role)+self.n(n-4)[:,None,:]
   x=x+torch.where(gate[:,:,None],self.gate(typ)+self.pos(pos)+self.angle(ang),self.obs(typ.clamp(max=1)))
   x=x*(gate|query)[:,:,None]
   for k in range(self.W):x[torch.arange(B),g+q+k]=self.work[k]+self.role.weight[2]
   x=self.norm(self.enc(x,src_key_padding_mask=~valid));slots=g[:,None]+torch.arange(55,device=device);out=x.gather(1,slots.clamp(max=178)[:,:,None].expand(-1,-1,64));out=out*(torch.arange(55,device=device)[None,:]<q[:,None])[:,:,None]
   return self.head(out).squeeze(-1)
 def tensor_data(W):
  packs=[pack(x,W) for x in rows];arrays=[torch.tensor(np.array(x),device=device) for x in zip(*packs)];labels=torch.zeros((len(rows),55),device=device)
  for k,x in enumerate(rows):labels[k,:len(x['labels'])]=torch.tensor(x['labels'],device=device)
  mask=torch.arange(55,device=device)[None,:]<arrays[7][:,None];return arrays,labels,mask
 tr=np.array([k for k,x in enumerate(rows) if x['split']=='train']);va=np.array([k for k,x in enumerate(rows) if x['split']=='validation']);logs=[]
 for seed in CONFIG['seeds']:
  for W in [0,4]:
   torch.manual_seed(seed);m=Model(W).to(device);optim=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.01);arrays,y,mask=tensor_data(W);order=np.random.default_rng(seed);start=time.perf_counter()
   for epoch in range(12):
    m.train();losses=[]
    for ids in np.array_split(order.permutation(tr),math.ceil(len(tr)/32)):
     ids=torch.tensor(ids,device=device);optim.zero_grad();pred=m([x[ids] for x in arrays]);loss=(((pred-y[ids])**2*mask[ids]).sum(1)/mask[ids].sum(1)).mean();loss.backward();nn.utils.clip_grad_norm_(m.parameters(),1.);optim.step();losses.append(loss.item())
    m.eval();preds=[]
    with torch.no_grad():
     for ids in np.array_split(va,math.ceil(len(va)/32)):
      ii=torch.tensor(ids,device=device);preds.append(m([x[ii] for x in arrays]).cpu().numpy())
    pr=np.concatenate(preds);yy=y[va].cpu().numpy();mm=mask[va].cpu().numpy();mae=np.mean((np.abs(pr-yy)*mm).sum(1)/mm.sum(1));rec=dict(seed=seed,W=W,epoch=epoch+1,train_mse=float(np.mean(losses)),validation_mae=float(mae),elapsed=time.perf_counter()-start);logs.append(rec);print(json.dumps(rec),flush=True)
    (ROOT/'curves.json').write_text(json.dumps(logs))
   np.savez(ROOT/f'predictions_s{seed}_w{W}.npz',pred=pr,indices=va);torch.save(m.state_dict(),ROOT/f'model_s{seed}_w{W}.pt')
 (ROOT/'finished.json').write_text(json.dumps({'completed_runs':6,'device':device}))
if __name__=='__main__':
 (ROOT/'config.json').write_text(json.dumps(CONFIG,indent=2));ledger,rows=generate();print('DATASET COMPLETE',len(rows),flush=True);train(ledger,rows)
