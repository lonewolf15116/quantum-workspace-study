import json,time,hashlib
from pathlib import Path
import numpy as np,torch
import model_from_p001 as m
p=Path(__file__).resolve().parent;src=p.parent/'pilot';torch.set_num_threads(4)
config=dict(seed=404,steps=500,lr=.001,batch=32,overfit_instances=32,phase_train=160,phase_validation=40,overfit_success_mae=.01,phase_success_Z0_mae=.05,interpretation='engineering targets, not scientific margins; failure not proof of a bug')
(p/'checks_config.json').write_text(json.dumps(config,indent=2));rows=json.loads((src/'instances.json').read_text());m.templates={t['template']:t for t in json.loads((src/'templates.json').read_text())};results=[];logs=[]
for task in ['overfit','phase']:
 if task=='overfit':
  data=[x for x in rows if x['split']=='train' and x['n']==4][:32];tr=np.arange(32);va=tr
 else:
  # 200 evenly spaced angles, interleaved holdout; new H=4 token, existing RZ=2.
  tid='phase_H_RZ_H';m.templates[tid]={'gates':[(4,0,10),(2,0,10),(4,0,10)]};data=[]
  for j,t in enumerate(np.linspace(-np.pi,np.pi,200,endpoint=False)):
   c=np.cos(t);labels=[c,1,1,1,c,c,c,1,1,1];data.append(dict(template=tid,n=4,angles=[float(t)],labels=labels))
  va=np.arange(0,200,5);tr=np.array([i for i in range(200) if i%5])
 packs=[m.pack(x,0) for x in data];arrays=[torch.tensor(np.array(x)) for x in zip(*packs)];y=torch.zeros((len(data),55));mask=torch.arange(55)[None,:]<arrays[7][:,None]
 for i,x in enumerate(data):y[i,:len(x['labels'])]=torch.tensor(x['labels'])
 torch.manual_seed(404);net=m.Model(0);opt=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.01);rng=np.random.default_rng(404);start=time.perf_counter()
 for step in range(501):
  if step%50==0:
   net.eval()
   with torch.no_grad():
    pred=net([x[va] for x in arrays]);err=(pred-y[va]).abs();mae=((err*mask[va]).sum(1)/mask[va].sum(1)).mean().item();z0=err[:,0].mean().item()
   log=dict(task=task,step=step,mae=mae,Z0_mae=z0,elapsed=time.perf_counter()-start);logs.append(log);print(json.dumps(log),flush=True);(p/'check_curves.json').write_text(json.dumps(logs))
  if step==500:break
  net.train();ids=rng.choice(tr,32,replace=False);opt.zero_grad();pr=net([x[ids] for x in arrays]);loss=(((pr-y[ids])**2*mask[ids]).sum(1)/mask[ids].sum(1)).mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1.);opt.step()
 results.append(dict(task=task,mae=mae,Z0_mae=z0,success=mae<.01 if task=='overfit' else z0<.05,elapsed=time.perf_counter()-start));np.savez(p/f'{task}_predictions.npz',pred=pred.numpy(),truth=y[va].numpy(),indices=va)
(p/'learning_checks.json').write_text(json.dumps(results,indent=2))
