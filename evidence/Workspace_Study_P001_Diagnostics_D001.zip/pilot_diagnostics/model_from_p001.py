import numpy as np
import torch
from torch import nn
device="cpu"
templates={}
def pack(row,W):
 n=row['n'];gates=templates[row['template']]['gates'];g=len(gates);q=n*(n+1)//2
 typ=np.zeros(179,int);i=np.full(179,10);j=i.copy();role=np.zeros(179,int);pos=np.zeros(179,int);ang=np.zeros((179,2),np.float32);a=iter(row['angles'])
 for k,(t,x,z) in enumerate(gates):
  typ[k]=t;i[k]=x;j[k]=z;pos[k]=k
  if t<3:v=next(a);ang[k]=[np.sin(v),np.cos(v)]
 queries=[(x,10) for x in range(n)]+[(x,z) for x in range(n) for z in range(x+1,n)]
 for k,(x,z) in enumerate(queries,g):role[k]=1;typ[k]=int(z!=10);i[k]=x;j[k]=z
 role[g+q:g+q+W]=2
 return typ,i,j,role,pos,ang,g,q,n
class Model(nn.Module):
 def __init__(self,W):
  super().__init__();self.W=W;d=64
  self.gate=nn.Embedding(6,d);self.obs=nn.Embedding(2,d);self.first=nn.Embedding(11,d);self.second=nn.Embedding(11,d);self.role=nn.Embedding(3,d);self.n=nn.Embedding(7,d);self.pos=nn.Embedding(128,d);self.angle=nn.Linear(2,d,bias=False);self.work=nn.Parameter(torch.randn(W,d)*.02)
  self.enc=nn.TransformerEncoder(nn.TransformerEncoderLayer(d,4,128,dropout=0.,activation='gelu',batch_first=True,norm_first=True),3,enable_nested_tensor=False);self.norm=nn.LayerNorm(d);self.head=nn.Linear(d,1)
 def forward(self,b):
  typ,i,j,role,pos,ang,g,q,n=b;B=len(g);idx=torch.arange(179,device=device)[None,:];gate=idx<g[:,None];query=(idx>=g[:,None])&(idx<(g+q)[:,None]);valid=idx<(g+q+self.W)[:,None]
  x=self.first(i)+self.second(j)+self.role(role)+self.n(n-4)[:,None,:]
  x=x+torch.where(gate[:,:,None],self.gate(typ)+self.pos(pos)+self.angle(ang),self.obs(typ.clamp(max=1)))
  x=x*(gate|query)[:,:,None]
  for k in range(self.W):x[torch.arange(B),g+q+k]=self.work[k]+self.role.weight[2]
  x=self.norm(self.enc(x,src_key_padding_mask=~valid));slots=g[:,None]+torch.arange(55,device=device);out=x.gather(1,slots.clamp(max=178)[:,:,None].expand(-1,-1,64));out=out*(torch.arange(55,device=device)[None,:]<q[:,None])[:,:,None]
  return self.head(out).squeeze(-1)
