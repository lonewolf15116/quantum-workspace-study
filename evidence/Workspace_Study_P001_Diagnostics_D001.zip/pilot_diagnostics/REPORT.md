# Pilot P001 diagnostics and learning checks D001

Exploratory follow-up, 2026-11-14. P001 is preserved; this is not a confirmatory workspace result.

## Label diagnostics

| Weighting | abs(label)<0.05 | abs(label)<0.10 | Mean absolute label |
|---|---:|---:|---:|
| Pooled 15,120 valid labels | 46.0648% | 60.2778% | 0.16014052 |
| Equal instances/templates, as study score | 39.7926% | 54.0601% | 0.18674571 |

Pooling overweights higher-qubit instances because they have more observables. Validation labels do cluster near zero but are not all negligible. Concentration alone does not establish an irreducible floor: exact labels are deterministic, and an ideal predictor can in principle attain zero error. Under MAE the optimal constant is a median, not a mean. A training mean losing to zero does not by itself prove train/validation mean bias. A weak fitted summary forest does not prove summary features contain no information.

## Per-cell comparisons

Using final predictions averaged across three seeds, W=4 beats W=0 in 49/63 cells. W=0 beats zero in 6/63; W=4 beats zero in 6/63. See per_cell.csv for every cell and by_qubits.json for n summaries. These are descriptive counts with only two validation templates and eight instances per cell; no significance or multiplicity-adjusted claim follows. Training and validation cover the SAME 63 cells with distinct templates, not held-out cells.

## Model output diagnostics

Across runs pooled prediction std is 0.0216–0.0364, compared with label std 0.2759. Mean absolute prediction is 0.0204–0.0291; output/label Pearson correlation is only 0.0051–0.0214. This is consistent with predictions clustered near zero with small variation and little learned instance-specific signal. It is not evidence of widely overconfident outputs. Full per-run means, spreads, thresholds and correlations are in diagnostics.json.

## Learning checks

Both use the P001 W=0 model, width 64, three layers, FFN128, P=179, CPU, one seed 404, AdamW lr=.001, weight decay=.01, batch32, clip1, 500 optimiser steps. Configuration including engineering success targets was saved before these checks. They are longer focused optimisation checks, NOT repetitions under the same P001 schedule.

- overfit: final MAE 0.000707098; Z0 MAE 0.000548119; engineering target passed=True; elapsed 34.23s.
- phase: final MAE 0.004992987; Z0 MAE 0.008901803; engineering target passed=True; elapsed 39.81s.

Overfit uses the first 32 n=4 P001 training instances, with the same instances scored; no generalisation claim. Phase uses H-RZ(theta)-H on qubit 0 of a four-qubit register with idle spectators, preserving the existing n=4 embedding domain. 200 evenly spaced angles on [-pi,pi), every fifth held out (160 train/40 validation). Z0 and pairs involving qubit 0 equal cos(theta); other observables equal 1. Labels are analytical. The H token uses the existing unused gate-table row 4. Report Z0 separately so constant spectator observables cannot hide failure. This is a fixed-template angle-interpolation check, not held-out-template generalisation. Because cos(theta) is supplied as an input feature, success establishes basic input-to-output utilisation, not discovery of quantum phase dynamics or general circuit reasoning.

Passing these tests weakens basic wiring/optimisation failure as an explanation but does not rule out all architecture, scale or optimisation issues. P001's main distribution has NOT been proved intrinsically uninformative. Next useful comparison is increased angles per fixed training template with separately reported within-template angle and held-out-template validation, retaining zero and training-only constant baselines. Do not change angle distributions or filter by label magnitude merely to manufacture a workspace difference.

## Scope and reproduction

GPU was unavailable; no laptop VRAM fit, GPU timing or peak-memory result is claimed. No Git commit or confirmatory run. Original P001 source and inputs are included in pilot/. Run diagnose.py and check_learning.py from pilot_diagnostics/ with P001 requirements (CPU torch). model_from_p001.py is an extracted copy of P001 pack/model definitions with module-level context, not a redesigned model. Checks log and configuration preserve the fixed budgets. Package digests are post-execution evidence, not preregistration. Dataset label diagnostics and threshold counts use existing P001 validation data.
