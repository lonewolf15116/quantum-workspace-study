from pathlib import Path
import numpy as np,json,csv
p=Path(__file__).resolve().parent;src=p.parent/'pilot';rows=json.loads((src/'instances.json').read_text());val=[i for i,x in enumerate(rows) if x['split']=='validation'];Y=np.concatenate([rows[i]['labels'] for i in val]);summary={'label_pooled':dict(count=len(Y),abs_lt_005=float(np.mean(np.abs(Y)<.05)),abs_lt_010=float(np.mean(np.abs(Y)<.1)),mean_abs=float(np.mean(np.abs(Y))),mean=float(Y.mean()),std=float(Y.std()))}
summary['label_instance_weighted']={f'abs_lt_{t}':float(np.mean([np.mean(np.abs(rows[i]['labels'])<t) for i in val])) for t in [.05,.1]};summary['label_instance_weighted']['mean_abs']=float(np.mean([np.abs(rows[i]['labels']).mean() for i in val]));outputs=[];all_errors={}
for seed in [101,202,303]:
 for w in [0,4]:
  z=np.load(src/f'predictions_s{seed}_w{w}.npz');pr=[];ys=[];err={}
  for a,i in zip(z['pred'],z['indices']):
   i=int(i);y=np.array(rows[i]['labels']);a=a[:len(y)];pr.extend(a.tolist());ys.extend(y.tolist());err[i]=float(np.abs(a-y).mean())
  a=np.array(pr);y=np.array(ys);outputs.append(dict(seed=seed,W=w,mean=float(a.mean()),std=float(a.std()),mean_abs=float(np.abs(a).mean()),abs_lt_005=float(np.mean(np.abs(a)<.05)),abs_lt_010=float(np.mean(np.abs(a)<.1)),max_abs=float(np.abs(a).max()),pearson=float(np.corrcoef(a,y)[0,1]),mae=float(np.mean(list(err.values())))));all_errors[(seed,w)]=err
cells=[]
for n in range(4,11):
 for r in [2,4,6]:
  for fam in ['path','ring','all_to_all']:
   ids=[i for i in val if (rows[i]['n'],rows[i]['r'],rows[i]['family'])==(n,r,fam)];zero=np.mean([np.abs(rows[i]['labels']).mean() for i in ids]);a={w:float(np.mean([all_errors[(s,w)][i] for s in [101,202,303] for i in ids])) for w in [0,4]};cells.append(dict(n=n,r=r,family=fam,zero_mae=zero,W0_mae=a[0],W4_mae=a[4],W0_minus_W4=a[0]-a[4],W0_beats_zero=a[0]<zero,W4_beats_zero=a[4]<zero))
summary.update(outputs=outputs,cell_counts=dict(W4_beats_W0=sum(x['W0_minus_W4']>0 for x in cells),W0_beats_zero=sum(x['W0_beats_zero'] for x in cells),W4_beats_zero=sum(x['W4_beats_zero'] for x in cells)))
(p/'diagnostics.json').write_text(json.dumps(summary,indent=2,default=lambda x:x.item()))
with (p/'per_cell.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(cells[0]));w.writeheader();w.writerows(cells)
print(json.dumps(summary,indent=2,default=lambda x:x.item()))
