# Step 02B-R1 — shared-capacity enumeration

WORKLOAD-002 / AC-002. Date: 2026-11-14.

**Selected primary comparator: d128_L04_W0, the masked-padding baseline.** It is the sole eligible candidate in both the original 15-point grid and diagnostic 588-point grid. Apply the original selection rule; no diagnostic substitution or grid expansion occurred.

| Policy | Reference arithmetic | Same-backbone arithmetic | Baseline difference | Original eligible | Joint eligible |
|---|---:|---:|---:|---:|---:|
| WORKLOAD-001, P=175+W | 353,231,634 | 343,861,550 | -2.652674% | 0/15 | 0/588 |
| WORKLOAD-002, P=179 | 353,231,634 | 353,231,122 | -0.000144947% | 1/15 | 1/588 |

Reference parameters 815,745; masked-padding baseline 815,233; difference -0.062764712%. Both +/-1% constraints pass. Reference arithmetic unchanged; baseline increases by 9,369,572 elementary operations relative to the old policy. The 512-operation remaining gap is workspace embedding addition. At the same backbone, charged special-function call counts and max-comparison counts also match under AC-002. None of this establishes equal measured runtime.

Expected useful arithmetic is unchanged: reference 163,959,464; baseline 156,093,124. Charged/useful ratios are 2.154384 and 2.262951 respectively. Useful compute is not matched. Reference parameters and useful ledgers are unchanged by the execution-policy amendment.

## Scope and reproducibility

The intervention activates four otherwise masked positions under fixed dense encoder capacity; it does not establish efficiency superiority over optimised unpadded inference. Original resource results were observed before choosing this policy. No training, model accuracy, GPU benchmark or scientific workspace-effect result exists.

ACCOUNTING.md defines AC-002 before the rerun. enumerate_resources.py reproduces resource tables using Python standard library only. input_manifest.json hashes the exact pre-enumeration inputs. The Step01 r3 annotation is clearly a post-enumeration document, not falsely represented as a prior input.

comparison_original_grid.csv and comparison_joint_grid.csv give every old and new result side by side. original_grid.csv and joint_grid.csv contain revised complete ledgers. per_cell.csv has 37,107 revised rows. reference.csv and results.json record the exact decision. The original Workspace_Study_Step_02B.zip is included byte-for-byte under historical/ and remains unchanged at its original location.

Internal checks passed: parameter formula versus shape inventory, component versus compact arithmetic, expected workload moments, tolerance boundaries, grid counts; additionally all old/new parameter and useful-arithmetic averages were checked identical across both grids. These are internal consistency checks, not independent model validation.

## Next checkpoint

Step 03 dataset specification and Step 05 analysis, numerical margin, training protocol, literature positioning and bounded independent review remain needed. Training must await the appropriate freezes. Git is deferred until the agreed specification checkpoint is complete and the repository destination is established.
