from fractions import Fraction as QF
from pathlib import Path
import json, csv, hashlib, math
BASE=Path(__file__).resolve().parent
CELLS=[(n,r,f) for n in range(4,11) for r in (2,4,6) for f in ('path','ring','all_to_all')]
def params(d,L,W):
    formula=L*(12*d*d+13*d)+(173+W)*d+1
    sizes=[6*d,2*d,11*d,11*d,3*d,7*d,128*d,2*d,W*d,2*d,d,1]
    for _ in range(L):
        sizes += [d*d,d]*4+[d*4*d,4*d,4*d*d,d]+[d,d]*2
    assert formula==sum(sizes)
    return formula

def count(d,L,W,n,r,useful=False):
    g=2*n*r;q=n*(n+1)//2;h=4
    p=g+q+W if useful else 179
    rows=q if useful else 55
    parts={'token':10*g*d+4*q*d+W*d,'matrix':L*(24*p*d*d+4*p*p*d),
           'bias':L*9*p*d,'norm':L*2*p*(7*d+1),'residual':L*2*p*d,
           'gelu':L*16*p*d,'scale':L*h*p*p,'softmax':L*h*(3*p*p-p),
           'final_norm':p*(7*d+1),'head':rows*(2*d+1)}
    total=sum(parts.values())
    assert total==10*g*d+4*q*d+W*d+L*(24*p*d*d+4*p*p*d+41*p*d+2*p+h*(4*p*p-p))+p*(7*d+1)+rows*(2*d+1)
    return dict(arithmetic=total,exp=L*h*p*p,erf=4*L*p*d,rsqrt=(2*L+1)*p,sin=g//2,cos=g//2,comparisons=L*h*p*(p-1))

def average(d,L,W,useful=False):
    values=[count(d,L,W,n,r,useful) for n,r,_ in CELLS]
    return {k:QF(sum(v[k] for v in values),63) for k in values[0]}
def eligible(f,p,rf,rp):return abs(f/rf-1)<=QF(1,100) and abs(QF(p,rp)-1)<=QF(1,100)
def qstr(x): return str(x)
def writecsv(name,rows):
    with (BASE/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    # Hash source specifications BEFORE evaluating any architecture.
    files=['ACCOUNTING.md','Workspace_Study_Step_01.md','Workspace_Study_Step_02A.md','enumerate_resources.py']
    manifest={p:{'sha256':hashlib.sha256((BASE/p).read_bytes()).hexdigest(),'bytes':(BASE/p).stat().st_size} for p in files}
    (BASE/'input_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    assert len(CELLS)==63
    assert sum(2*n*r for n,r,_ in CELLS)==63*56
    assert sum(n*(n+1)//2 for n,_,_ in CELLS)==63*30
    assert eligible(QF(101),101,QF(100),100)
    assert not eligible(QF(10101,100),100,QF(100),100)
    rf=average(128,4,4)['arithmetic'];rp=params(128,4,4)
    configs=[(128,4,4)]+[(d,L,0) for d in range(64,257,4) for L in range(1,13)]
    rows=[];cells=[]
    for d,L,W in configs:
        p=params(d,L,W);a=average(d,L,W);u=average(d,L,W,True)
        original=W==0 and d in (96,112,128,144,160) and L in (3,4,5)
        row=dict(id=f'd{d:03}_L{L:02}_W{W}',d=d,L=L,W=W,parameters=p,original=original,
                 charged_exact=qstr(a['arithmetic']),useful_exact=qstr(u['arithmetic']),
                 charged=float(a['arithmetic']),useful=float(u['arithmetic']),
                 compute_delta_pct=float(100*(a['arithmetic']/rf-1)),param_delta_pct=float(100*(QF(p,rp)-1)),
                 charged_over_useful=float(a['arithmetic']/u['arithmetic']),eligible=eligible(a['arithmetic'],p,rf,rp))
        for k in a:
            if k!='arithmetic': row['charged_'+k]=qstr(a[k]);row['useful_'+k]=qstr(u[k])
        rows.append(row)
        for n,r,fam in CELLS:
            ac=count(d,L,W,n,r);uc=count(d,L,W,n,r,True)
            c=dict(id=row['id'],n=n,r=r,family=fam,gates=2*n*r,queries=n*(n+1)//2,valid_positions=2*n*r+n*(n+1)//2+W,padded_positions=179)
            for k in ac:c['charged_'+k]=ac[k];c['useful_'+k]=uc[k]
            cells.append(c)
    orig=[x for x in rows if x['original']];joint=[x for x in rows if x['W']==0]
    assert len(orig)==15 and len(joint)==588 and len(cells)==589*63
    writecsv('original_grid.csv',orig);writecsv('joint_grid.csv',joint);writecsv('per_cell.csv',cells);writecsv('reference.csv',[rows[0]])
    oe=[x for x in orig if x['eligible']];je=[x for x in joint if x['eligible']]
    oe.sort(key=lambda x:(abs(QF(x['charged_exact'])-rf),x['parameters'],x['L'],x['id']))
    result=dict(reference=rows[0],same_backbone=next(x for x in orig if x['d']==128 and x['L']==4),original_eligible=oe,joint_eligible=je,primary_selection=oe[0]['id'] if oe else None,validation='PASS: parameter shape inventory, component arithmetic, workload moments, eligibility boundary and row counts',evaluated_configurations=589,per_cell_rows=len(cells))
    (BASE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
