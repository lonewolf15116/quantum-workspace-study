# Step 02B — accounting convention AC-002

Date: 2026-11-14. Defined before executing the accompanying enumeration.
Scope: analytical inference accounting, not trained-model results or measured GPU instructions. WORKLOAD-002 and both 1% bands are held fixed for this calculation. This is a resource-analysis freeze, not full study preregistration.

## Scalar and boundaries

The primary matching scalar F is elementary floating-point arithmetic under the conventional matrix-product charge of two operations per multiply-accumulate (2mkn for m-by-k times k-by-n). Each scalar add, subtraction, multiplication or division counts one. Matrix products use this convention even though a minimal dot product has k-1 additions. Bias additions are separate. Special functions (exp, erf, rsqrt, sin, cos) and comparisons are reported separately with NO invented equivalent-FLOP weighting. Thus F excludes special-function internals; a match in F is not a match in total hardware cost. Report this limitation wherever interpreting a match. The previous phrase 'compute matched' means this explicitly restricted arithmetic budget.

Inference includes token embedding summations, rotation-feature projection, all encoder operations including padding, final LayerNorm on all encoder positions, and scalar readout. Angle feature sin/cos calls are in a separate ledger; indexing, integer work, memory moves, mask assignments and model loading are outside F. No backward pass, optimiser, loss or metric computation is included. Constants such as inverse sqrt(head dimension), inverse width and inverse sqrt(2) are precomputed. Dropout is zero.

## Parameter instantiation

All models allocate these tables, including unused rows: gate types 6d; observable types 2d; first-qubit and second-qubit tables each 11d (0..9 and NONE); roles 3d; qubit-count table 7d (4..10); gate positions 128d. Shared bias-free rotation projection: 2d. These total 170d. Workspace vectors add Wd; the workspace role row is retained even for W=0. Unused table entries remain in allocated trainable parameter count; do not claim every allocated entry receives gradients. Position rows 120..127 are unused under this workload.

Each block: Q/K/V/output weights 4d^2 and biases 4d; FFN d->4d->d weights 8d^2 and biases 5d; two affine LayerNorms 4d. Total 12d^2+13d. Final affine LayerNorm 2d; shared scalar head d+1.

Total parameters: L(12d^2+13d)+(173+W)d+1. Four equal heads require d divisible by four. All original-grid widths satisfy this.

## Arithmetic formulas per circuit

Let g=2nr, Q=n(n+1)/2, h=4. Charged encoder length P=179 and readout rows R=55. Useful logical alternative: P=g+Q+W and R=Q. Useful excludes trailing padding and absent readout rows, but uses identical arithmetic conventions.

Token construction: 10gd+4Qd+Wd. Seven terms are summed for each gate (6d additions); its 2-to-d projection costs 4d. Five query terms require 4d additions. Workspace vector plus role costs d each. Rotation features execute only on rotation gates: g/2 sin and g/2 cos calls; every gate receives projection, including CNOT zero features. Embeddings are constructed only for valid tokens; trailing zero rows are allocated by memory operations outside F.

One LayerNorm on one d-vector: mean d-1 additions and one multiplication; d centering subtractions; variance d squares, d-1 additions and one multiplication; epsilon one addition; one rsqrt call; d normalisation multiplies; d affine multiplies and d affine adds. Elementary total 7d+1, plus one rsqrt.

Each block:
- Projection and FFN matrix products: 24Pd^2.
- QK^T and attention-value products: 4P^2d.
- Linear biases: 9Pd.
- Two LayerNorms: 2P(7d+1).
- Two residual additions: 2Pd.
- GELU: 4 arithmetic operations and one erf per FFN element: 16Pd arithmetic, 4Pd erf calls.
- Attention scaling: hP^2 multiplies.
- Stable softmax over ALL P keys: hP^2 subtractions, hP(P-1) summation adds, hP^2 divisions, hP^2 exp calls and hP(P-1) max comparisons. Masked keys are assigned -infinity before softmax; exp(-infinity) is still charged as a call. Padded query rows are processed; at least one valid key exists.

Combining: B=24Pd^2+4P^2d+41Pd+2P+h(4P^2-P).

F=10gd+4Qd+Wd+L*B+P(7d+1)+R(2d+1).

Ledger: exp=LhP^2; erf=4LPd; rsqrt=(2L+1)P; sin=g/2; cos=g/2; max comparisons=LhP(P-1). Mask writes are not floating-point arithmetic. Useful ledger omits padding masks. This is a declared dense evaluation algorithm; a fused implementation may execute differently and must be profiled separately rather than asserted identical.

Expected values use exact rational averaging over the 63 equally weighted workload cells. Report ratio of expected charged/useful counts and per-cell ratios separately.

## Enumeration order and decisions

Original grid: d in {96,112,128,144,160}, L in {3,4,5}, W=0. Reference d=128,L=4,W=4. Freeze the convention and input hashes before computing results. Both absolute relative differences, denominated by reference, must be <=1/100. Exact rational comparisons, no rounding in eligibility. Select eligible original candidates by absolute expected-F distance, then parameters, depth, lexicographic ID.

Separate diagnostic joint grid: d=64,68,...,256; L=1,...,12; W=0 (588 points, including original points). This finite range spans half to twice reference width and one to three times reference depth. It is selected before enumeration and is not expanded adaptively in this run. Its candidates cannot enter the original primary decision. Report every eligible diagnostic candidate; if any exist, a later amendment still must justify adopting it. Empty joint eligibility is only a statement about this finite range, never a universal impossibility claim.

## Validation and limits

Check parameter formulas against an independently constructed tensor-shape inventory. Check simplified arithmetic against a component-by-component sum across all evaluated cells. Check expected workload moments and exact boundary eligibility. These validate the analytic implementation, not a neural-network runtime; no runtime model is instantiated or GPU benchmark claimed. The accounting scalar deliberately excludes special-function internals and memory cost. No sample-size, accuracy, novelty or scientific workspace-effect conclusion follows from enumeration.


## R1 change record
Shared charged P=179 replaces P=175+W for all primary-grid and diagnostic candidates. All other arithmetic and parameter formulas, original/diagnostic grids, eligibility bands and ordering remain unchanged. Original resource outcomes were observed before this amendment; no training outcomes exist. The primary contrast converts four reserved masked-padding slots into learned workspace. W=2 is a separately trained secondary model activating the first two reserved slots; it is not a subset of a trained W=4 model. W=8 is excluded here; a prospective separate study could set common P=183 and re-enumerate all controls, disclosing prior results. No W=2 or W=8 performance is evaluated here.
