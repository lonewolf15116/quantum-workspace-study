# Step 02B — resource enumeration results

Date: 2026-11-14. Convention AC-001; WORKLOAD-001 / Step02A-r2.

## Outcome

**Primary comparator unavailable as specified.** Original grid: 0/15 eligible. Diagnostic joint grid: 0/588 eligible, widths 64–256 in steps of four, depths 1–12. Both bands remain +/-1%. This finite search does not prove global infeasibility. No model training, accuracy evaluation or GPU profiling occurred.

The input manifest hashes the two archived source annexes, accounting convention and executable source. The convention was written before this execution. Its scalar counts elementary arithmetic with MAC=2; special-function calls and comparisons are separately reported and NOT assigned FLOP equivalents. Results are exact under that convention, not measured hardware costs.

## Reference and same backbone

| Model | Parameters | Expected charged arithmetic | Expected useful arithmetic | Charged/useful |
|---|---:|---:|---:|---:|
| d128_L04_W4 | 815,745 | 353,231,634 | 163,959,464 | 2.1544 |
| d128_L04_W0 | 815,233 | 343,861,550 | 156,093,124 | 2.2029 |

Same-backbone differences relative to reference: arithmetic -2.652674%; allocated parameters -0.062765%. It passes the parameter band and fails the arithmetic band. Useful-arithmetic matching is not asserted. Average charged/useful ratios show substantial padding overhead; they are ratios of expectations, not averages of cell ratios.

## Complete original grid

| Width | Layers | Parameters | Charged arithmetic (millions) | Arithmetic difference | Parameter difference | Both eligible |
|---:|---:|---:|---:|---:|---:|---|
| 96 | 3 | 352,129 | 155.130620 | -56.0825% | -56.8334% | False |
| 96 | 4 | 463,969 | 206.776270 | -41.4616% | -43.1233% | False |
| 96 | 5 | 575,809 | 258.421920 | -26.8407% | -29.4131% | False |
| 112 | 3 | 475,329 | 203.320060 | -42.4400% | -41.7307% | False |
| 112 | 4 | 627,313 | 271.018110 | -23.2747% | -23.0994% | False |
| 112 | 5 | 779,297 | 338.716160 | -4.1093% | -4.4681% | False |
| 128 | 3 | 616,961 | 257.960700 | -26.9712% | -24.3684% | False |
| 128 | 4 | 815,233 | 343.861550 | -2.6527% | -0.0628% | False |
| 128 | 5 | 1,013,505 | 429.762400 | +21.6659% | +24.2429% | False |
| 144 | 3 | 777,025 | 319.052540 | -9.6761% | -4.7466% | False |
| 144 | 4 | 1,027,729 | 425.306590 | +20.4044% | +25.9866% | False |
| 144 | 5 | 1,278,433 | 531.560640 | +50.4850% | +56.7197% | False |
| 160 | 3 | 955,521 | 386.595580 | +9.4453% | +17.1348% | False |
| 160 | 4 | 1,264,801 | 515.353230 | +45.8967% | +55.0486% | False |
| 160 | 5 | 1,574,081 | 644.110880 | +82.3480% | +92.9624% | False |

## Diagnostic examples from the wider grid

These are disclosures, not alternate selections. Some leading-order parameter estimates in the submitted review differ materially from the full counts.

| Width | Layers | Arithmetic difference | Parameter difference | Both eligible |
|---:|---:|---:|---:|---|
| 116 | 5 | +2.0491% | +2.3566% | False |
| 112 | 5 | -4.1093% | -4.4681% | False |
| 132 | 4 | +2.8833% | +6.1671% | False |
| 104 | 6 | +0.9615% | -1.3347% | False |

## Evidence and validation

- ACCOUNTING.md: scalar definition, individual operations, parameter table sizes and formulas, both search ranges and scope.
- enumerate_resources.py: standard-library-only reproduction; run `python enumerate_resources.py` from any directory.
- original_grid.csv: all 15 candidates, useful/charged averages and special-function ledgers.
- joint_grid.csv: all 588 diagnostic candidates and eligibility.
- per_cell.csv: 37,107 rows covering reference plus joint grid, each on 63 cells, with useful/charged arithmetic and function-call ledgers.
- reference.csv and results.json: reference counts and decision result.
- input_manifest.json: SHA-256 and byte lengths of the exact input specifications and source.

Internal checks passed: parameter formula versus separate tensor-shape inventory; combined arithmetic versus component sum; exact workload moments E[g]=56 and E[Q]=30; inclusive tolerance boundary; grid/cell row counts. These checks are not an independent implementation audit, a trained-model test or a runtime profiler check.

## Disposition

Keep the original primary decision unavailable; do not substitute a diagnostic candidate or change the band. A later design amendment must acknowledge both enumerations were observed and justify any architectural, budget or execution-policy change scientifically. Per-instance/packed inference would remove padding waste but NOT remove the four additional useful positions or guarantee feasibility. No such change is made here. This result concerns resource compatibility, not whether workspace improves prediction.
